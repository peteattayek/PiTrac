#!/bin/bash
echo "Verifying XNNPACK provider in ONNX Runtime..."
echo ""
XNNPACK_COUNT=$(strings /usr/lib/aarch64-linux-gnu/libonnxruntime.so | grep -ci xnnpack || true)
if [ "$XNNPACK_COUNT" -gt 0 ]; then
    echo "✓ XNNPACK provider is present! ($XNNPACK_COUNT symbols found)"
    echo ""
    echo "Key XNNPACK symbols:"
    strings /usr/lib/aarch64-linux-gnu/libonnxruntime.so | grep "XnnpackExecutionProvider" | head -3
else
    echo "✗ XNNPACK provider not found"
fi

echo ""
echo "Python verification:"
echo "python3 -c \"import onnxruntime; print('Providers:', onnxruntime.get_available_providers())\""
